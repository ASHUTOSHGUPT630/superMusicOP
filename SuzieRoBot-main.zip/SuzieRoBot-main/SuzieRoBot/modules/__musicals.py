__mod_name__ = "MUSIC"

__help__ = """
 ❍ /song <song name>*:* Uploads the song in it's best quality available
 💡Ex: `/song Faded Alan Walker`
 ❍ /saavn <song name>*:* Download song from saavn.
"""
