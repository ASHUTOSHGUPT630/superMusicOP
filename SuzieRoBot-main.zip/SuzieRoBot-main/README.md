
<h1 align="center"><b>❤️ Suzie Robot  ❤️</b></h1>

<h4 align="center">A Powerful, Smart And Simple Group Manager <br> ... Written with AioGram , Pyrogram and Telethon...</h4>
<p align='center'>
  <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-1f425f.svg?style=flat-square&logo=python&color=blue" /> </a>
  <a href="https://github.com/W2HGalaxy-OP/SuzieRoBot/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/Maintained%3F-yes-green.svg?style=flat-square" /> </a>
</p>

<p align="center"><a href="https://t.me/SuzieRoBot_support"><img src="https://telegra.ph/file/152074fd0e34541dcdc4b.jpg" width="400"></a></p>

<p align="center">
    <a href="https://app.codacy.com/manual/W2HGalaxy-OP/SuzieRoBot/dashboard"> <img src="https://img.shields.io/codacy/grade/4d58f2a402b54aed8a7d95f7add45a81?color=brightgreen&logo=codacy&logoColor=green&style=for-the-badge" alt="Codacy" /></a>
    <a href="https://github.com/W2HGalaxy-OP/SuzieRoBot"> <img src="https://img.shields.io/github/repo-size/W2HGalaxy-OP/SuzieRoBot?color=orange&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/W2HGalaxy-OP/SuzieRoBot/commits/prince"> <img src="https://img.shields.io/github/last-commit/W2HGalaxy-OP/SuzieRoBot?color=brown&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/W2HGalaxy-OP/SuzieRoBot/issues"> <img src="https://img.shields.io/github/issues/W2HGalaxy-OP/SuzieRoBot?color=blueviolet&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/W2HGalaxy-OP/SuzieRoBot/network/members"> <img src="https://img.shields.io/github/forks/W2HGalaxy-OP/SuzieRoBot?color=red&logo=github&logoColor=green&style=for-the-badge" /></a>  
    <a href="https://pypi.org/project/Telethon/"> <img src="https://img.shields.io/pypi/v/telethon?color=yellow&label=telethon&logo=python&logoColor=green&style=for-the-badge" /></a>
</p>

> ⭐️ Thanks to everyone who starred Suzie, That is the greatest pleasure we have !

## Avaiilable on Telegram as [@SuzieRoBot](https://t.me/SuzieRoBot)

## ✨ Easy To Deploy ✨
The easiest way to deploy this Bot

To get Telethon String Session Tap on This ➤ [Generate String Session](https://replit.com/@GalaxyOp/W2HBOT#main.py)

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/W2HGalaxy-OP/SuzieRoBot"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
 
 
# ❤️ Support
<a href="https://t.me/SuzieRoBot_support"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>
<a href="https://t.me/SuzieRoBot_updates"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>

## Contributers

- [Galaxy](https://github.com/W2HGalaxy-OP)
- [Gaurav](https://github.com/iisgaurav)

## CREDITS

- [PaulSonOfLars](https://github.com/PaulSonOfLars/tgbot)
- [Saitama](https://github.com/AnimeKaizoku)
- [Loli-Killer](https://github.com/Loli-Killer)
- [RealAkito](https://github.com/RealAkito)
- [MrYacha](https://github.com/MrYacha)
- [Shreyansh](https://github.com/okay-retard)
- [Ayush](https://github.com/MissJuliaRobot/MissJuliaRobot)
- [Inuka Asith](https://github.com/inukaasith)
- [Legendx](https://github.com/LEGENDXOP)
- [Amarnath c](https://github.com/Amarnathcdj)
- [Thehamkercat](https://github.com/thehamkercat)
- [DragSama](https://github.com/DragSama)
- [Shrimadhav](https://github.com/SpEcHiDe)
- [Ayra Hikari](https://github.com/AyraHikari)
- [Masha Robot](https://github.com/Mr-Dark-Prince/MashaRoBot)
